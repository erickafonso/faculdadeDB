/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.faculdade;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author fltreib
 */
public class Equipamentos {
    private int id;
    private String nome;


    public String getNome() {
        return nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Equipamentos(String nome) {
        this.nome = nome;

    }
     public void cadastrar(){
        String sql =  "INSERT INTO equipamentos (nome) VALUES ( "
                    + " '" + this.getNome() +   "  ) "
    ;
        Conexao.executar( sql );
    }
    
    public void editar(){
        String sql =  "UPDATE equipamentos SET  "
                    + " nome    = '" + this.getNome() +   "   "

                    + " WHERE id = " + this.getId();
        Conexao.executar( sql );
    }
    
    public static void excluir(int id){
        String sql =  "DELETE FROM equipamentos WHERE id = " + id;
        Conexao.executar( sql );
    }
    
    
    public static ArrayList<Equipamentos> getEquipamentos(){
        ArrayList<Equipamentos> lista = new ArrayList<>();
        
        String sql = "SELECT id, nome FROM equipamentos ORDER BY nome ";
        
        ResultSet rs = Conexao.consultar( sql );
        
        if( rs != null){
            
            try{
                while ( rs.next() ) {                
                    String nome = rs.getString( 2 );

                    Equipamentos equipamento = new Equipamentos(nome);
                    equipamento.setId( rs.getInt( "id" ) );
                    lista.add( equipamento );
                }
            }catch(Exception e){
                
            }
            
        }
     
        return lista;
    }
}