/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.faculdade;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author 182310022
 */
public class Sala {
    private int id;
    private String andar, tipo, capacidade;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Sala(String capacidade, String andar, String tipo) {
        this.andar = andar;
        this.tipo = tipo;
        this.capacidade = capacidade;
    }



    public String getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(String capacidade) {
        this.capacidade = capacidade;
    }



    public String getAndar() {
        return andar;
    }

    public void setAndar(String andar) {
        this.andar = andar;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
     
    public void cadastrar(){
        String sql =  "INSERT INTO sala (capacidade, andar, tipo) VALUES ( "
                    + " '" + this.getCapacidade() +   "' ,  "
                    + " '" + this.getAndar() +  "' ,  "
                    + "  " + this.getTipo() +"  ) ";
        Conexao.executar( sql );
    }
    
    public void editar(){
        String sql =  "UPDATE sala SET  "
                    + " capacidade    = '" + this.getCapacidade() +   "' ,  "
                    + " andar   = '" + this.getAndar() +  "' ,  "
                    + " tipo =  " + this.getTipo() +"     "
                    + " WHERE id = " + this.getId();
        Conexao.executar( sql );
    }
    
    public static void excluir(int id){
        String sql =  "DELETE FROM sala WHERE id = " + id;
        Conexao.executar( sql );
    }
    
    
    public static ArrayList<Sala> getSala(){
        ArrayList<Sala> lista = new ArrayList<>();
        
        String sql = "SELECT id, capacidade, andar, tipo FROM sala ORDER BY nome ";
        
        ResultSet rs = Conexao.consultar( sql );
        
        if( rs != null){
            
            try{
                while ( rs.next() ) {                
                    String capacidade = rs.getString( "capacidade" );
                    String tipo = rs.getString( "tipo" );
                    String andar = rs.getString("andar" );
                    Sala sala = new Sala(capacidade,andar, tipo);
                    sala.setId( rs.getInt( "id" ) );
                    lista.add( sala );
                }
            }catch(Exception e){
                
            }
            
        }
     
        return lista;
    }
    
}
