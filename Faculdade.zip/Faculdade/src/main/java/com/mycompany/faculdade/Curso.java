/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.faculdade;

/**
 *
 * @author 182310022
 */
import java.sql.ResultSet;

import java.util.ArrayList;

public class Curso {
    private String nome, duracao, descricao, modalidade;
    private int idCurso;
    private double valor;
        
        
    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Curso(String nome, String duracao, double valor) {
        this.nome = nome;
        this.duracao = duracao;
        this.valor = valor;
    }
    
    
    public void cadastrar(){
        String sql =  "INSERT INTO curso (nome, duracao, valor, descricao, modalidade) VALUES ( "
                    + " '" + this.getNome() +   "' ,  "
                    + " '" + this.getDuracao() +  "' ,  "
                    + "  " + this.getValor() +"' ,  "
                    + "  " + this.getDescricao() +"' ,  "
                    + "  " + this.getModalidade() +"  ) ";
        Conexao.executar( sql );
    }
    
    public void editar(){
        String sql =  "UPDATE curso SET  "
                    + " nome    = '" + this.getNome() +   "' ,  "
                    + " duracao   = '" + this.getDuracao() +  "' ,  "
                    + " valor =  " + this.getValor() +"     "
                    + " descricao =  " + this.getDescricao() +"     "
                    + " modadlidade =  " + this.getModalidade() +"     "
                    + " WHERE idCurso = " + this.getIdCurso();
        Conexao.executar( sql );
    }
    
    public static void excluir(int idCurso){
        String sql =  "DELETE FROM curso WHERE idCurso = " + idCurso;
        Conexao.executar( sql );
    }
    
    
    public static ArrayList<Curso> getCurso(){
        ArrayList<Curso> lista = new ArrayList<>();
        
        String sql = "SELECT idCurso, nome, duracao, valor, descricao, modalidade FROM curso ORDER BY nome ";
        
        ResultSet rs = Conexao.consultar( sql );
        
        if( rs != null){
            
            try{
                while ( rs.next() ) {                
                    String nome = rs.getString("nome" );
                    String duracao = rs.getString( "duracao" );
                    double valor = rs.getDouble("valor" );
                    Curso curso = new Curso(nome, duracao, valor);
                    curso.setIdCurso( rs.getInt( "idCurso" ) );
                    lista.add( curso );
                }
            }catch(Exception e){
                
            }
            
        }
     
        return lista;
    }
}

