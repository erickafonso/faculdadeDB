/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.faculdade;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author 182310022
 */
public class Contato {
    private int idTelefone;
    private String ddd, numero, email;

    public Contato(String ddd, String numero) {
        this.ddd = ddd;
        this.numero = numero;
    }

    public String getDdd() {
        return ddd;
    }

    public int getIdTelefone() {
        return idTelefone;
    }

    public void setIdTelefone(int idTelefone) {
        this.idTelefone = idTelefone;
    }

    

    public void setDdd(String ddd) {
        this.ddd = ddd;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
     public void cadastrar(){
        String sql =  "INSERT INTO contato (ddd, numero, email) VALUES ( "
                    + " '" + this.getDdd() +   "' ,  "
                    + " '" + this.getNumero() +  "' ,  "
                    + "  " + this.getEmail() +"  ) ";
        Conexao.executar( sql );
    }
    
    public void editar(){
        String sql =  "UPDATE contato SET  "
                    + " nome    = '" + this.getDdd() +   "' ,  "
                    + " email   = '" + this.getNumero() +  "' ,  "
                    + " salario =  " + this.getEmail() +"     "
                    + " WHERE idTelefone = " + this.getIdTelefone();
        Conexao.executar( sql );
    }
    
    public static void excluir(int idTelefone){
        String sql =  "DELETE FROM contato WHERE idTelefone = " + idTelefone;
        Conexao.executar( sql );
    }
    
    
    public static ArrayList<Contato> getContato(){
        ArrayList<Contato> lista = new ArrayList<>();
        
        String sql = "SELECT idTelefone, ddd, numero, email FROM contato ORDER BY nome ";
        
        ResultSet rs = Conexao.consultar( sql );
        
        if( rs != null){
            
            try{
                while ( rs.next() ) {                
                    String ddd = rs.getString( "ddd" );
                    String numero = rs.getString( "numero" );
                    String email = rs.getString( "email" );
                    
                    Contato contato = new Contato(ddd, numero);
                    contato.setIdTelefone( rs.getInt( "idTelefone" ) );
                    lista.add( contato );
                }
            }catch(Exception e){
                
            }
            
        }
     
        return lista;
    }
}
